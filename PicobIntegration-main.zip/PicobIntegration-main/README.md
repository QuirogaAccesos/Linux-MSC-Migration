Este DLL establece comunicacion para el envio de comandos y la recepcion de datos del dispositivo PICOB

……
## Instalación Rápida
1. Descargar el DLL a utilizar de [aqui](https://github.com/TREA-AA/PicobIntegration/releases/tag/1.0.0.0)
2. Incluya todos los archivos necesarios para utilizar el dll en su proyecto.
3. implementar la interfase y la clase con los datos IPicobController [Nombre de objeto] = new PicobController();

## Datos técnicos
Es un proyecto con un DLL para .net 8 o mayor 

## Metodos a Utilizar
* Metodos utilizables del dll:

### PicobController💻

* #### bool OpenPicobPort(string serialPort)
  * Inicia la comunicacion y valida que su apertura sea correcta. Devuelve true o false
  * Debe recibir como parametro el puerto serial a utilizar con formato: "COM1"
    
* #### bool ClosePort();
   * Metodo para detener la comunicacion con el dispositivo PICOB
     
* #### string[] PicobDataRequest(int timeout)
   * Metodo para recibir un String array de un largo de 10 datos.
   * Puede recibir como parametro el timeout maximo de respuesta del metodo en ms.
     
* #### string[] PicobDataRequest()
   * Metodo para recibir un String array de un largo de 10 datos.
     
* #### bool IsPortOpen()
   * Regresa True si la conexion con el puerto esta abierta y false si esta cerrada
     
* #### SendDataToPicob(string command)
   * Metodo Creado para enviar diferentes comandos al dispositivo PICOB las letras pueden ser enviadas en mayuscula o minuscula.
     
### PicobAL1Controller💻

* #### bool OpenPicobPort(string serialPort, int baudRate = 115200);
  * Inicia la comunicacion y valida que su apertura sea correcta. Devuelve true o false
  * Debe recibir como parametro el puerto serial a utilizar con formato: "COM1"
  * Puede modificarse el numero de baudrate pero ya tiene por defecto el estandar para este tipo de picob
    
* #### bool ClosePort();
   * Metodo para detener la comunicacion con el dispositivo PICOB
   * Devuelve true si la desconexion fue exitosa
     
* #### bool IsPortOpen()
   * Regresa True si la conexion con el puerto esta abierta y false si esta cerrada
     
* #### string SendDataToPicob(char command, int maxTimeout = 1500);
   * Metodo Creado para enviar diferentes comandos al dispositivo PICOB las letras pueden ser enviadas en mayuscula o minuscula pero debe ser solo un caracter
   * el tiemout es el tiempo maximo de espera para tener respuesta de picob[^1].
 
  [^1]: Los tiempos segun comandos pueden cambiar es recomendable validar bien esto.
