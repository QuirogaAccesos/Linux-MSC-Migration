﻿using PicobControllers;
using PicobControllers.Controllers;

#region Picob Lite

//IPicobLite pico = new PicobLiteController();


//pico.OpenPicobPort("COM4");

//while (true)
//{
//    var _data = pico.PicobDataRequest();
//    for (int i = 0; i < _data.Length; i++)
//    {
//        Console.Write($"{i + 1} = {_data[i]} ,");
//    }
//    Console.WriteLine("");
//}

#endregion



IPicob picobAL1 = new PicobLiteController();

picobAL1.OpenPicobPort("/dev/ttyUSB0");

while (true)
{
    Console.WriteLine();
    Console.WriteLine($"Response: {picobAL1.SendToPicobAndReceive("X")}");
    Console.WriteLine();
}