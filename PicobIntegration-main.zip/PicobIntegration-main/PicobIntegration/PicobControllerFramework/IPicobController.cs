﻿namespace PicobControllers
{
    public interface IPicobController
    {
        /// <summary>
        /// Method to open the serial port and have a confirmation of the operation
        /// </summary>
        /// <param name="serialPort"> Port to open Format example: COM10 </param>
        /// <returns></returns>
        bool OpenPicobPort(string serialPort);


        /// <summary>
        /// Method to close the serial port and have a confirmation of the operation
        /// </summary>
        /// <returns></returns>
        bool ClosePort();


        /// <summary>
        /// Method to request the data from the picob device
        /// </summary>
        /// <param name="timeout">timeout of the operation</param>
        /// <returns></returns>
        string[] PicobDataRequest(int timeout);

        /// <summary>
        /// Method to request the data from the picob device
        /// </summary>
        /// <returns></returns>
        string[] PicobDataRequest();

        /// <summary>
        /// Method to answer if the picob device is on
        /// </summary>
        /// <returns></returns>
        bool IsPortOpen();

        /// <summary>
        /// Method to send Commands to the picob
        /// </summary>
        /// <param name="command"></param>
        void SendDataToPicob(string command);
    }
}
