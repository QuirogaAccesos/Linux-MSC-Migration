﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.IO.Ports;
using System.Threading;

namespace Serialport
{
  
    internal class SerialPortController
    {
        //Variable utilizada para usar los metodos de SerialPort mas facilmente
        public SerialPort serialport;

        //Evento de datos en buffer Serial
        private ManualResetEvent dataReceivedEvent = new ManualResetEvent(false);

        /// <summary>
        /// Metodo para abrir los puertos seriales con ciertos datos predefinidos
        /// </summary>
        /// <param name="port">Nombre del puerto COM que se va a abrir con formato: COM9 </param>
        public void Open_port(string port)
        {
            try
            {
                serialport = new SerialPort();
                serialport.PortName = port;
                serialport.BaudRate = 9600;
                serialport.DataBits = 8;
                serialport.StopBits = StopBits.One;
                serialport.Parity = Parity.None;
                serialport.Handshake = Handshake.None;


                serialport.DataReceived += Serialport_DataReceived;

                serialport.Open();
            }
            catch
            {
                //MessageBox.Show("Error al abrir, Verifique el puerto COM", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        /// <summary>
        /// Evento que indica que se recibieron datos del puerto serial
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Serialport_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            dataReceivedEvent.Set();
        }

        /// <summary>
        /// Metodo utilizado para cerrar los puerto com abiertos
        /// </summary>
        public void Close_port()
        {
            serialport.Close();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool isPortOpen()
        {
            return serialport.IsOpen;
        }


        /// <summary>
        /// Escritura basi a un puerto serial
        /// </summary>
        /// <param name="data"></param>
        public void WriteToSerialPort(string data)
        {
            serialport.Write(data);
        }


        /// <summary>
        /// Envio de datos byte a byte al puerto serial
        /// </summary>
        /// <param name="Datos">Datos a enviar por el puerto serial</param>
        /// <returns></returns>
        public string commandToSerialPort(string _datos)
        {
            if(!isPortOpen()) 
            {
                return "Port Close";
            }
            serialport.DiscardInBuffer();
            serialport.DiscardOutBuffer();

            //Envio de datos byte a byte
            serialport.Write(_datos);
            Thread.Sleep(150);
            //Se espera un segundo antes de iniciar el proceso de leer los datos

            if (dataReceivedEvent.WaitOne(5000)) // Esperar máximo 7 segundos
            {
                // Reiniciar el evento de recibo de datos
                dataReceivedEvent.Reset();
                string Respuesta = serialport.ReadExisting();

                serialport.DiscardInBuffer();
                serialport.DiscardOutBuffer();


                return Respuesta;
            }
            throw new Exception("Picob Fail");
        }
    }
}