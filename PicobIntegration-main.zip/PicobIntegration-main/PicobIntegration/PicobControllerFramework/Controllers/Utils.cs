﻿using System;

namespace PicobControllers.Controllers
{
    internal class Utils
    {
        /// <summary>
        /// Metodo para devolver un string en bytes, la cadena de datos que reciba siempre debe ser par
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public static string[] DivideCommand(string command)
        {
            try
            {
                command = command.Replace("&\r\n", ""); ;
                var split = command.Split('$');

                string[] _data = new string[split.Length];
                for (int index = 0; index < split.Length; index++)
                {
                    var i = split[index];

                    if (i.Length > 3)
                    {
                        var start = i.Replace(i.Substring(0, 3),"");

                        _data[index] = start;
                    }
                    else if (i.Length == 3)
                    {
                        var start = i.Replace(i.Substring(0, 2),"");
                        _data[index] = start;
                    }
                    else
                    {
                        throw new Exception("error");
                    }
                }
                return _data;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
