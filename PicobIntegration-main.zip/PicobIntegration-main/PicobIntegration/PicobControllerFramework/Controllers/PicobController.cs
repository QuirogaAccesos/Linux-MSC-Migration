﻿using Serialport;
using System.Threading;

namespace PicobControllers.Controllers 
{
    public class PicobController : IPicobController
    {
        SerialPortController comPort = new SerialPortController();

        /// <summary>
        /// Method to open the serial port and have a confirmation of the operation
        /// </summary>
        /// <param name="serialPort"> Port to open Format example: COM10 </param>
        /// <returns></returns>
        public bool OpenPicobPort(string serialPort)
        {
            comPort.Open_port(serialPort);
            Thread.Sleep(100);
            return comPort.isPortOpen();
        }

        /// <summary>
        /// Method to request the data from the picob device
        /// </summary>
        /// <param name="timeout">timeout of the operation</param>
        /// <returns></returns>
        public string[] PicobDataRequest(int timeout)
        {
            string[] res = Utils.DivideCommand(comPort.commandToSerialPort("X"));
            Thread.Sleep(timeout);
            return res ;
        }

        /// <summary>
        /// Method to request the data from the picob device
        /// </summary>
        /// <returns></returns>
        public string[] PicobDataRequest()
        {
            string[] res = Utils.DivideCommand(comPort.commandToSerialPort("X"));
            Thread.Sleep(200);
            return res;
        }

        /// <summary>
        /// Method to answer if the picob device is on
        /// </summary>
        /// <returns></returns>
        public bool IsPortOpen() 
        {
            return comPort.isPortOpen();
        }

        /// <summary>
        /// Method to close the serial port and have a confirmation of the operation
        /// </summary>
        /// <returns></returns>
        public bool ClosePort() 
        {
            comPort.Close_port();
            return !comPort.isPortOpen();
        }

        /// <summary>
        /// Method to send Commands to the picob
        /// </summary>
        /// <param name="command">Command to send to the picob device</param>
        public void SendDataToPicob(string command) 
        {
            command = command.ToUpper();
            comPort.WriteToSerialPort(command);
        }
    }
}
