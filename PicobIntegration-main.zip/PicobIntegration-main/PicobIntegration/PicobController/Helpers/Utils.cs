﻿namespace PicobControllers.Helpers
{
    internal class Utils
    {
        /// <summary>
        /// Metodo para devolver un string en bytes, la cadena de datos que reciba siempre debe ser par
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public static string[] DivideCommand(string command)
        {
            try
            {
                // Protecciones básicas
                if (command == null)
                    throw new ArgumentNullException(nameof(command));

                // Quitar CR/LF y dividir
                var segments = command
                    .Replace("&\r\n", "")
                    .Split(new[] { '$' }, StringSplitOptions.RemoveEmptyEntries);

                // Para cada segmento, recorta los 3 o 2 caracteres de cabecera según su longitud
                return segments
                    .Select(s =>
                        s.Length > 3
                          ? s.Substring(3)
                          : s.Length == 3
                            ? s.Substring(2)
                            : string.Empty)
                    .ToArray();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
