﻿
namespace PicobControllers
{
    /// <summary>
    /// Interface for PicobLite
    /// </summary>
    public interface IPicobLite : IPicob
    {
        /// <summary>
        /// Sends a command character to the Picob device and waits up to<paramref name="maxTimeout"/> ms for a response.
        /// </summary>
        /// <param name="maxTimeout"> Timeout in milliseconds (default is <c>1500</c> ms). </param>
        /// <returns>Array with all Picob Lite standart response</returns>
        /// <exception cref="TimeoutException">
        /// When no response is received within <paramref name="maxTimeout"/> milliseconds.
        /// </exception>
        /// <exception cref="IOException">
        ///   When there is a communication error sending the command.
        /// </exception>
        string[] PicobDataRequest(int maxTimeout);

        /// <summary>
        /// Sends a command character to the Picob device and waits up a max of 1500ms for a response.
        /// </summary>
        /// <returns>Array with all Picob Lite standart response</returns>
        /// <exception cref="TimeoutException">
        ///   When no response is received within 1500 milliseconds.
        /// </exception>
        /// <exception cref="IOException">
        ///   When there is a communication error sending the command.
        /// </exception>
        string[] PicobDataRequest();
    }
}
