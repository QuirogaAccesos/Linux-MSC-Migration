﻿namespace PicobControllers
{
    /// <summary>
    /// Defines the contract for controlling a Picob device via a serial port.
    /// Used for Picob V2 (AL1 and SBK)
    /// Its a general no specific use for the Picob device
    /// </summary>
    public interface IPicob
    {
        /// <summary>
        /// Gets whether the serial port to the Picob device is open.
        /// </summary>
        /// <returns>
        /// <c>true</c> if the port is open; otherwise, <c>false</c>.
        /// </returns>
        bool IsPortOpen();

        /// <summary>
        /// Opens the serial-port connection to the Picob device.
        /// </summary>
        /// <param name="serialPort">
        /// The port name (e.g., "COM3").
        /// </param>
        /// <param name="baudRate">
        /// The baud rate in bits per second (default is <c>115200</c>).
        /// </param>
        /// <param name="dtr">
        /// Activate DTR (default is false).
        /// </param>
        /// <param name="rts">
        /// Activate RTS (default is false).
        /// </param>
        /// <param name="newline">
        /// Set newline behaviour (default is \n).
        /// </param>
        /// <returns>
        /// <c>true</c> if the port opened successfully; otherwise, <c>false</c>.
        /// </returns>
        /// <exception cref="ArgumentException">
        ///   When <paramref name="serialPort"/> is null, empty or has an invalid format.
        /// </exception>
        /// <exception cref="UnauthorizedAccessException">
        ///   When the current process does not have permission to access the serial port.
        /// </exception>
        /// <exception cref="IOException">
        ///   When the serial port cannot be opened due to an I/O error.
        /// </exception>
        bool OpenPicobPort(string serialPort, int baudRate = 115200, bool dtr = false, bool rts = false, string newline = "\n");

        /// <summary>
        /// Sends a command character to the Picob device and waits up to <paramref name="maxTimeout"/> ms for a response.
        /// </summary>
        /// <param name="command">The command characters (case-insensitive).</param>
        /// <param name="maxTimeout">Timeout in milliseconds (default is <c>1500</c> ms).</param>
        /// <returns>The response string from the device.</returns>
        /// <exception cref="TimeoutException">
        ///   When no response is received within <paramref name="maxTimeout"/> milliseconds.
        /// </exception>
        /// <exception cref="IOException">
        ///   When there is a communication error sending the command.
        /// </exception>
        string SendToPicobAndReceive(string command, int maxTimeout = 1500);

        /// <summary>
        /// Sends a command character to the Picob device without waiting for a response.
        /// </summary>
        /// <param name="command">The command characters (case-insensitive).</param>
        /// <exception cref="IOException">
        ///   When there is a communication error sending the command.
        /// </exception>
        void SendToPicob(string command);

        /// <summary>
        /// Closes the serial-port connection to the Picob device.
        /// </summary>
        /// <returns>
        /// <c>true</c> once the port is closed; <c>false</c> if it remains open.
        /// </returns>
        /// <exception cref="IOException">
        ///   When there is an error closing the serial port.
        /// </exception>
        bool ClosePort();
    }
}
