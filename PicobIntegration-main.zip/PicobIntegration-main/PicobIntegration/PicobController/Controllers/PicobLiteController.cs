﻿
using PicobControllers.Helpers;
using Serialport;


namespace PicobControllers.Controllers 
{
    public class PicobLiteController : PicobController , IPicobLite
    {
     
        /// <summary>
        /// Method return the datas of the signals of the Picob Device
        /// NO NEED timeout if used in a While
        /// </summary>
        /// <returns></returns>
        public string[] PicobDataRequest(int timeout)
        {
            string fullResponse = comPort.Command("X", timeout);

            if (string.IsNullOrEmpty(fullResponse))
                throw new Exception("No response from Picob device.");

            string[] res = Utils.DivideCommand(fullResponse);
            return res ;
        }

        public string[] PicobDataRequest()
        {
            string fullResponse = comPort.Command("X");

            if (string.IsNullOrEmpty(fullResponse))
                throw new Exception("No response from Picob device.");

            string[] res = Utils.DivideCommand(fullResponse);

            Thread.Sleep(200);
            return res;
        }
    }
}
