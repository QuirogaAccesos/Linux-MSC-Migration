﻿using System.IO.Ports;

namespace Serialport
{
  
    internal class SerialPortController : IDisposable
    {
        //Variable utilizada para usar los metodos de SerialPort mas facilmente
        public SerialPort _port;
        public static SerialPort Instance;

        //Evento de datos en buffer Serial
        private readonly ManualResetEventSlim _dataReceived = new();

        private readonly object _syncRoot = new();

        /// <summary>
        /// Metodo para abrir los puertos seriales con ciertos datos predefinidos
        /// </summary>
        /// <param name="port">Nombre del puerto COM que se va a abrir con formato: COM9 </param>
        public void OpenPort(string port, int baudRate = 9600, int dataBits = 8, StopBits stopBits = StopBits.One,
            Parity parity = Parity.None, Handshake handshake = Handshake.None, bool dtr = false, bool rts = false,
            string newline = "\n")
        {
            try
            {
                this._port = new SerialPort();
                _port.PortName = port;
                _port.BaudRate = baudRate;
                _port.DataBits = dataBits;
                _port.StopBits = stopBits;
                _port.Parity = parity;
                _port.Handshake = handshake;
                _port.DtrEnable = dtr; // Habilitar DTR para algunos dispositivos
                _port.RtsEnable = rts; // Habilitar RTS para algunos dispositivos
                _port.NewLine = newline;

                _port.DataReceived += OnDataReceived;

                _port.Open();
                Instance = _port; // Asignar la instancia actual a la propiedad estática
            }
            catch
            {
                throw new Exception("Fail Open SerialPort: " + port);
            }
        }


        /// <summary>
        /// Metodo utilizado para cerrar los puerto com abiertos
        /// </summary>
        public void ClosePort()
        {
            if (_port.IsOpen) _port.Close();
        }


        /// <summary>
        /// metodo para saber si el puerto esta abierto
        /// </summary>
        /// <returns></returns>
        public bool IsPortOpen => _port.IsOpen;

        /// <summary>
        /// Evento que se lanza cuando se reciben datos en el puerto serial
        /// </summary>
        /// <param name="s"></param>
        /// <param name="e"></param>
        private void OnDataReceived(object s, SerialDataReceivedEventArgs e) => _dataReceived.Set();


        public string Command(string datos, int timeoutMs = 1500 , bool WaitForResponse = true)
        {
            if (!_port.IsOpen)
                throw new InvalidOperationException("Puerto cerrado.");

            if (string.IsNullOrWhiteSpace(datos))
                throw new ArgumentException("El comando no puede estar vacío.", nameof(datos));

            if (!WaitForResponse)
            {
                _port.Write(datos);
                return string.Empty;
            }

            lock (_syncRoot)
            {

                _dataReceived.Reset();
                _port.DiscardInBuffer();
                _port.DiscardOutBuffer();

                _port.Write(datos);
               
                // esperamos por el evento o timeout
                if (!_dataReceived.Wait(timeoutMs))
                    throw new TimeoutException($"No hubo respuesta en {timeoutMs} ms.");

                Thread.Sleep(175);
                var respuesta = _port.ReadExisting();
                return respuesta;
            }
        }

        //Metodo nuevo falta probar simba asda
        //public string Command(string datos, int timeoutMs = 1500, bool WaitForResponse = true)
        //{
        //    if (!_port.IsOpen)
        //        throw new InvalidOperationException("Puerto cerrado.");

        //    if (string.IsNullOrWhiteSpace(datos))
        //        throw new ArgumentException("El comando no puede estar vacío.", nameof(datos));

        //    if (!WaitForResponse)
        //    {
        //        _port.Write(datos);
        //        return string.Empty;
        //    }

        //    lock (_syncRoot)
        //    {
        //        _dataReceived.Reset();
        //        _port.DiscardInBuffer();
        //        _port.DiscardOutBuffer();

        //        // Asegurar que el buffer esté listo
        //        _port.Write(datos);

        //        // Incrementar el tiempo de espera en Linux
        //        int adjustedTimeout = Environment.OSVersion.Platform == PlatformID.Unix ?
        //            timeoutMs * 2 : timeoutMs;

        //        // Agregar un pequeño retraso después de escribir (especialmente para Linux)
        //        Thread.Sleep(50);

        //        // Esperar por el evento o timeout
        //        if (!_dataReceived.Wait(adjustedTimeout))
        //        {
        //            // Intentar leer de todos modos antes de lanzar excepción
        //            var respuestaFallback = _port.ReadExisting();
        //            if (!string.IsNullOrEmpty(respuestaFallback))
        //                return respuestaFallback;

        //            throw new TimeoutException($"No hubo respuesta en {adjustedTimeout} ms.");
        //        }

        //        // Retraso adicional para asegurar datos completos
        //        Thread.Sleep(200);
        //        var respuesta = _port.ReadExisting();
        //        return respuesta;
        //    }
        //}

        public void Dispose()
        {
            _port.DataReceived -= OnDataReceived;
            if (_port.IsOpen) _port.Close();
            _port.Dispose();
            _dataReceived.Dispose();
        }
    }
}