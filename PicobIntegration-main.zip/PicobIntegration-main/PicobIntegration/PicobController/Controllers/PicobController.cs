﻿using Serialport;

namespace PicobControllers.Controllers
{
    /// <inheritdoc/>
    public class PicobController : IPicob
    {
        internal readonly SerialPortController comPort = new SerialPortController();

        /// <inheritdoc/>
        public bool IsPortOpen() => comPort.IsPortOpen;

        /// <inheritdoc/>
        public bool OpenPicobPort(string serialPort, int baudRate = 115200, bool _dtr = false, bool _rts = false, string _newline = "\n")
        {
            comPort.OpenPort(serialPort, baudRate, dtr: _dtr, rts: _rts, newline: _newline);
            Task.Delay(100).Wait(); 
            return comPort.IsPortOpen;
        }

        /// <inheritdoc/>
        public string SendToPicobAndReceive(string command, int maxTimeout = 1500) => comPort.Command(command.ToUpperInvariant(), maxTimeout);

        /// <inheritdoc/>
        public bool ClosePort()
        {
            comPort.ClosePort();
            return !comPort.IsPortOpen;
        }

        /// <inheritdoc/>
        public void SendToPicob(string command) => comPort.Command(command.ToUpperInvariant(), WaitForResponse: false);

    }
}

