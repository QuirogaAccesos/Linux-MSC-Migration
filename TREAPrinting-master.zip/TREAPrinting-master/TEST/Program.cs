﻿using ParkingTerminalApp.Libraries.PrintController;

for (int i = 0; i < 1; i++)
{
    //PrintControl.PrintTicket();
    //Thread.Sleep(5000);
    PrintControl.PrintTicket();
}