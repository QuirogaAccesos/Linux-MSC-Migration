﻿
using NanoidDotNet;
using System.Configuration;


namespace ParkingTerminalApp.Libraries.PrintController
{

    public class PrintDiccionary
    {
        public Dictionary<string, string> printDiccionary = new Dictionary<string, string>();

        // no ser usa
        public PrintDiccionary()
        {

            printDiccionary.Add("#Terminal", ConfigurationManager.AppSettings["TerminalId"] ?? "1");
            printDiccionary.Add("#DATE", DateTime.Now.ToString());
            printDiccionary.Add("#VisibleId", Nanoid.Generate());
            printDiccionary.Add("#Plate", "Plate");
            printDiccionary.Add("#TicketVisibleId", "456489498");
        }
    }
}
