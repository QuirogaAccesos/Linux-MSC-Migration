﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingTerminalApp.Libraries.PrintController
{
    public static class PrinterConstants
    {
        public static string font = ConfigurationManager.AppSettings["printerFont"] ?? "Consolas";
        public static int textSize = int.Parse(ConfigurationManager.AppSettings["printerTextSize"] ?? "8");
        public static string printingFile = ConfigurationManager.AppSettings["printingFile"] ?? "PrintingTemplates/TicketFormat.txt";
        public static bool printImageOnTicket = bool.Parse(ConfigurationManager.AppSettings["printLogoOnTicket"] ?? "true");
        public static string LogoPath = ConfigurationManager.AppSettings["LogoPath"] ?? "PrintingTemplates/TREA.png";
        public static int LogoSize = int.Parse(ConfigurationManager.AppSettings["LogoPrintSize"] ?? "12");
        public static int QRSize = int.Parse(ConfigurationManager.AppSettings["QrPrintSize"] ?? "24");
        public static string HeaderAlignment = ConfigurationManager.AppSettings["LogoPrintAlignment"] ?? "center";
        public static string FooterAlignment = ConfigurationManager.AppSettings["QrPrintAlignment"] ?? "center";
        public static int printerPaperSize = int.Parse(ConfigurationManager.AppSettings["printerPaperSize"] ?? "58");
    }
}
