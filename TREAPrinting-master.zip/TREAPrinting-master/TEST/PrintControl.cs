﻿using QRCoder;
using System.Drawing;
using System.Text;
using TREAPrinting;
using TREAPrinting.Printer.Controllers;
using TREAPrinting.Printer.Modelos.TREAPrinting;

namespace ParkingTerminalApp.Libraries.PrintController
{
    public class PrintControl
    {


        public static void PrintTicket()
        {
            try
            {
                // El controlador ahora será nuestra nueva implementación multiplataforma
                IPrinterController _printerController = new CrossPlatformPrinterController();

                byte[]? logoBytes = LoadImageAsBytes(PrinterConstants.LogoPath);
                byte[] qrBytes = GenerateQrCode("hola");

                var _printDiccionary = new PrintDiccionary();

                _printerController.Print(
                    PrinterConstants.printingFile,
                    _printDiccionary.printDiccionary,
                    PrinterConstants.font,
                    PrinterConstants.textSize,
                    PrinterConstants.printerPaperSize,
                    footer: qrBytes,
                    header: logoBytes
                );
            }
            catch (Exception ex)
            { 
                throw new Exception("Printing Error: " + ex.Message, ex);
            }
        }


        /// <summary>
        /// MODO DINÁMICO:
        /// Ejemplo de cómo imprimir usando PrintDynamic(...) para lograr
        /// una salida similar al "clásico" pero construyendo manualmente
        /// la lista de PrintElement (logo, texto, QR).
        /// </summary>
        public static void PrintTicketDynamic()
        {
            try
            {
                // 1. Preparamos el controlador
                IPrinterController _printerController = new CrossPlatformPrinterController();

                // 2. Cargamos el logo (opcional) como bytes
                byte[]? logoBytes = null;
                if (PrinterConstants.printImageOnTicket)
                {
                    logoBytes = LoadImageAsBytes(PrinterConstants.LogoPath);
                }

                // 3. Obtenemos el texto de la plantilla y aplicamos el diccionario
                PrintDiccionary _printDiccionary = new PrintDiccionary();
                string replacedText = BuildReplacedText(
                    PrinterConstants.printingFile,
                    _printDiccionary.printDiccionary
                );

                string[] blocks = replacedText.Split(new[] { "@@QR@@" }, StringSplitOptions.None);

                // Por seguridad, manejamos el caso de que no exista la marca:
                string block1 = (blocks.Length > 0) ? blocks[0] : replacedText;  // todo el texto si no existe @@QR@@
                string block2 = (blocks.Length > 1) ? blocks[1] : "";

                // 4. Generamos el QR como bytes
                byte[] qrBytes = GenerateQrCode("hola");

                // 5. Construimos la lista de PrintElement
                var elements = new List<PrintElement>();

                if (logoBytes != null)
                {
                    elements.Add(new PrintElement { ImageData = logoBytes, Alignment = "center" /*, ...*/ });
                }

                if (!string.IsNullOrWhiteSpace(block1))
                {
                    elements.Add(new PrintElement { Text = block1, Alignment = "center" /*, ...*/ });
                }

                elements.Add(new PrintElement { ImageData = qrBytes, Alignment = "center" /*, ...*/ });

                if (!string.IsNullOrWhiteSpace(block2))
                {
                    elements.Add(new PrintElement { Text = block2, Alignment = "center" /*, ...*/ });
                }

                // 6. Imprimimos en modo dinámico
                _printerController.PrintDynamic(elements, PrinterConstants.printerPaperSize);
            }
            catch (Exception ex) { /* ... Manejo de error ... */ }
        }


        /// <summary>
        /// Carga el archivo de plantilla, y reemplaza las llaves {KEY} con los
        /// valores del diccionario para obtener el texto final.
        /// </summary>
        private static string BuildReplacedText(
            string textFileLocalAddress,
            Dictionary<string, string> variableDictionary)
        {
            var sb = new StringBuilder();

            // 1) Leemos el archivo de texto
            foreach (var line in File.ReadLines(textFileLocalAddress))
            {
                sb.AppendLine(line);
            }

            // 2) Reemplazamos {KEY} con VALUE
            foreach (var kv in variableDictionary)
            {
                sb.Replace(kv.Key, kv.Value);
            }

            return sb.ToString();
        }


        /// <summary>
        /// Genera un QR Code con el contenido que se le pase y devuelve un Bitmap.
        /// </summary>
        /// <param name="content">Texto que contendrá el QR.</param>
        /// <returns>Un Bitmap con la imagen del QR generado.</returns>
        /// <summary>
    /// Genera un QR Code y devuelve sus datos como un arreglo de bytes.
    /// </summary>
    private static byte[] GenerateQrCode(string content)
    {
        using (var qrGenerator = new QRCodeGenerator())
        {
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(content, QRCodeGenerator.ECCLevel.Q);
            using (var qrCode = new BitmapByteQRCode(qrCodeData))
            {
                // Este método ya devuelve los bytes del bitmap, ¡perfecto!
                byte[] qrCodeAsBitmapByteArr = qrCode.GetGraphic(10);
                return qrCodeAsBitmapByteArr;
            }
        }
    }

    /// <summary>
    /// Carga una imagen desde un archivo y la devuelve como arreglo de bytes.
    /// </summary>
    private static byte[]? LoadImageAsBytes(string path)
    {
        if (File.Exists(path))
        {
            return File.ReadAllBytes(path);
        }
        return null;
    }

    }
}
