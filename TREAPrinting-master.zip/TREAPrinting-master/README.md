# TREAPrinting
DLL para el uso de la impresoras de 58mm o de 80mm funciona para imprimir textos apartir de un template y dando la posibilidad de incluir imagenes, y ademas incluir variables en el texto a imprimir.

## Instalación Rápida
1. Descargar el DLL a utilizar
2. Incluya el DLL en el proyecto como referencia.
3. Incluya los Nugget Necesarios del proyecto.
4. implementar la interfase y la clase con los datos.
   ``` C#
   IPrinterController [Nombre de objeto] = new PrinterController();
   ```

## Datos técnicos
Creado utilizando .net 8.0 
Requiere incluir nugget System.Drawing.Common

## Implementacion de Interface
A continuacion se podran ver los metodos, eventos y atributos utilizables del DLL

* ####  void Print(string templateAdress, Dictionary<string, string> variableDictionary, string TextFont, int TextSize, int PaperSize,
     Bitmap header = null, int HeaderSize = 12, string headerAlignment = "center",
     Bitmap footer = null, int FooterSize = 12, string footerAlignment = "center");

* El Heater y el Footer son Bitmap y es importante apuntar el alineamiento y el tamaño de las imagenes.
### Modo  minimo de uso    

* ####  void Print(string templateAdress, Dictionary<string, string> variableDictionary, string TextFont, int TextSize, int PaperSize);
