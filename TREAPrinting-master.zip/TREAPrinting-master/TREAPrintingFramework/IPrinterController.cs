﻿using System.Collections.Generic;
using System.Drawing;


namespace TREAPrintingFramework
{
    public interface IPrinterController
    {
        /// <summary>
        /// Replaces the template string with the variable values, set the text font and size for the printed output
        /// </summary>
        /// <param name="templateAdress"></param>
        /// <param name="variableDictionary"></param>
        /// <param name="TextFont"></param>
        /// <param name="TextSize"></param>
        /// <param name="header"></param>
        /// <param name="footer"></param>
        void Print(string templateAdress, Dictionary<string, string> variableDictionary, string TextFont, int TextSize, int PaperSize,
            Bitmap header = null, int HeaderSize = 12, string headerAlignment = "center",
            Bitmap footer = null, int FooterSize = 12, string footerAlignment = "center");


        void PrintDynamic(
           List<PrintElement> elements,
           int paperSize
       );
    }
}
