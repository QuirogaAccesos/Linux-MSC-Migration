﻿using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Text;


namespace TREAPrintingFramework
{
    public class PrinterController : IPrinterController
    {
        private readonly StringBuilder _toPrintStringBuilder = new StringBuilder();
        private readonly PrintDocument _printDocument = new PrintDocument();

        // ==== Variables para el modo "clásico" ====
        private string textToPrint;   // Contenido de texto tras reemplazar variables
        private string textFont;      // Fuente usada al imprimir el texto
        private int textSize;         // Tamaño de fuente
        private Bitmap _header;       // Imagen de header
        private Bitmap _footer;       // Imagen de footer

        // ==== Variables para parámetros de alineación y papel (modo clásico) ====
        private string _headerAlignment;
        private string _footerAlignment;
        private int _paperSize;       // p.ej. 58, 80, etc.

        // ==== Variables para el modo "dinámico" ====
        private List<PrintElement> _dynamicElements;
        

        #region Normal Print With header and footer

        public void Print(
            string templateAddress,
            Dictionary<string, string> variableDictionary,
            string TextFont,
            int TextSize,
            int PaperSize,
            Bitmap header = null,
            int HeaderSize = 12,
            string headerAlignment = "center",
            Bitmap footer = null,
            int FooterSize = 12,
            string footerAlignment = "center")
        {
            // Guardamos en variables de instancia
            _paperSize = PaperSize;
            _headerAlignment = headerAlignment;
            _footerAlignment = footerAlignment;

            // Guardamos fuente y tamaño de texto
            textFont = TextFont;
            textSize = TextSize;

            // Redimensionar las imágenes si existen
            _header = ResizeImage(header, HeaderSize);
            _footer = ResizeImage(footer, FooterSize);

            // Construir el texto a imprimir (reemplazar variables, etc.)
            _printTextBuilder(templateAddress, variableDictionary);

            // Antes de suscribir, desuscribimos cualquier evento anterior
            _printDocument.PrintPage -= _printPage;
            _printDocument.PrintPage -= _printPageDynamic;

            // Suscribimos el método "clásico"
            _printDocument.PrintPage += _printPage;

            // Enviamos a imprimir
            _printDocument.Print();
        }

        /// <summary>
        /// Lee la plantilla .txt y reemplaza las variables {KEY} por los valores del diccionario.
        /// </summary>
        private void _printTextBuilder(string textFileLocalAddress, Dictionary<string, string> variableDictionary)
        {
            _toPrintStringBuilder.Clear();

            var textSeparatedByLines = File.ReadLines(textFileLocalAddress);
            foreach (var line in textSeparatedByLines)
            {
                _toPrintStringBuilder.AppendLine(line);
            }

            // Reemplazar {KEY} con VALUE
            foreach (var kv in variableDictionary)
            {
                _toPrintStringBuilder.Replace(kv.Key, kv.Value);
            }

            textToPrint = _toPrintStringBuilder.ToString();
        }

        /// <summary>
        /// Evento PrintPage para el modo "clásico".
        /// Firma obligatoria: (object sender, PrintPageEventArgs e)
        /// </summary>
        private void _printPage(object sender, PrintPageEventArgs e)
        {
            float yPos = 0f;

            // Lógica original para "Imagecenter" en el texto
            float Imagecenter = 0f;
            if (_paperSize == 58)
                Imagecenter = 3.1f;
            else if (_paperSize == 80)
                Imagecenter = 2f;

            // 1) Dibujar header
            if (_header != null)
            {
                // Centramos la imagen del header según _headerAlignment
                float headerXPos = GetGenericAlignedXPosition(e.PageBounds.Width, _header.Width, _headerAlignment);
                e.Graphics.DrawImage(_header, new Rectangle((int)headerXPos, (int)yPos, _header.Width, _header.Height));
                yPos += _header.Height + 10;
            }

            // 2) Dibujar texto
            using (var font = new Font(textFont, textSize))
            {
                float textWidth = e.Graphics.MeasureString(textToPrint, font).Width;

                // Centramos el texto según "Imagecenter"
                float textXPos = GetGenericAlignedXPosition(e.PageBounds.Width, (int)textWidth, "center");

                // Ajuste adicional para 58 mm
                if (_paperSize == 58)
                {
                    textXPos = 3;
                }

                e.Graphics.DrawString(textToPrint, font, Brushes.Black, new PointF(textXPos, yPos));

                // Calculamos altura del texto y actualizamos yPos
                float textHeight = e.Graphics.MeasureString(textToPrint, font).Height;
                yPos += textHeight + 8;
            }

            // 3) Dibujar footer
            if (_footer != null)
            {
                float footerXPos = GetGenericAlignedXPosition(e.PageBounds.Width, _footer.Width, _footerAlignment);
                e.Graphics.DrawImage(_footer, new Rectangle((int)footerXPos, (int)yPos, _footer.Width, _footer.Height));
            }

            // Aquí podrías manejar e.HasMorePages = true si necesitas más páginas
        }

        #endregion

        #region Dinamic Print

        /// <summary>
        /// Permite imprimir una lista dinámica de elementos (texto/imágenes)
        /// en cualquier orden. Cada elemento tiene su propia alineación.
        /// </summary>
        public void PrintDynamic(List<PrintElement> elements, int paperSize)
        {
            _dynamicElements = elements;


            // Desuscribimos cualquier handler anterior
            _printDocument.PrintPage -= _printPage;
            _printDocument.PrintPage -= _printPageDynamic;

            // Suscribimos el método para impresión dinámica
            _printDocument.PrintPage += _printPageDynamic;

            // Disparamos la impresión
            _printDocument.Print();
        }

        /// <summary>
        /// Evento PrintPage para el modo "dinámico".
        /// Recorre la lista de PrintElement y los imprime en orden.
        /// </summary>
        private void _printPageDynamic(object sender, PrintPageEventArgs e)
        {
            float yPos = 0f;

            // Recorremos todos los PrintElement en orden
            foreach (var elem in _dynamicElements)
            {
                // 1) Imprimir texto
                if (!string.IsNullOrEmpty(elem.Text))
                {
                    using (Font font = new Font(elem.FontFamily, elem.FontSize))
                    {
                        SizeF textSize = e.Graphics.MeasureString(elem.Text, font);
                        float xPos = GetGenericAlignedXPosition(e.PageBounds.Width, textSize.Width, elem.Alignment);

                        e.Graphics.DrawString(elem.Text, font, Brushes.Black, new PointF(xPos, yPos));
                        yPos += textSize.Height + elem.SpacingAfter;
                    }
                }

                // 2) Imprimir imagen
                if (elem.Image != null)
                {
                    float sizeMm = (float)elem.ImageSize;

                    // Llamamos a tu método ResizeImage para ajustar la imagen a 'sizeMm' mm de ancho
                    using (Bitmap resizedImage = ResizeImage(elem.Image, sizeMm))
                    {
                        float xPos = GetGenericAlignedXPosition(e.PageBounds.Width, resizedImage.Width, elem.Alignment);

                        // Dibujamos la imagen reescalada
                        e.Graphics.DrawImage(
                            resizedImage,
                            new Rectangle((int)xPos, (int)yPos, resizedImage.Width, resizedImage.Height)
                        );

                        yPos += resizedImage.Height + elem.SpacingAfter ;
                    }
                }
            }

            // Si necesitas varias páginas, manipula e.HasMorePages
        }

        #endregion

        #region Helpers

        /// <summary>
        /// Redimensiona (escala) una imagen a un ancho en mm, conservando su relación de aspecto.
        /// </summary>
        private Bitmap ResizeImage(Bitmap image, float targetWidthMm)
        {
            if (image == null) return null;

            float dpi = 203f; // DPI típico de impresoras térmicas
            float targetWidthInPixels = (targetWidthMm / 25.4f) * dpi; // mm -> px

            float scale = targetWidthInPixels / image.Width;
            int targetHeightInPixels = (int)(image.Height * scale);

            var resizedImage = new Bitmap((int)targetWidthInPixels, targetHeightInPixels);
            using (Graphics g = Graphics.FromImage(resizedImage))
            {
                g.DrawImage(image, 0, 0, resizedImage.Width, resizedImage.Height);
            }
            return resizedImage;
        }

        /// <summary>
        /// Función de alineación genérica (left, center, right) para el modo dinámico.
        /// Siempre centrado real => (pageWidth - elementWidth) / 2f si alignment = "center".
        /// </summary>
        private float GetGenericAlignedXPosition(float pageWidth, float elementWidth, string alignment)
        {
            switch (alignment.ToLower())
            {
                case "left":
                    return 0f;
                case "center":
                    return (pageWidth - elementWidth) / 2f;
                case "right":
                    return pageWidth - elementWidth;
                default:
                    return 0f;
            }
        }

        #endregion
    }
}
