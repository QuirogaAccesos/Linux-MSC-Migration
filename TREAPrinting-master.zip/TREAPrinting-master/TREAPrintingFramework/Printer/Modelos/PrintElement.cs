﻿
using System.Drawing;

namespace TREAPrintingFramework
{
    public class PrintElement
    {
        /// <summary>
        /// Texto opcional a imprimir.
        /// Si no quieres imprimir texto, déjalo null o vacío.
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// Imagen opcional (logo, QR, etc.)
        /// Si no hay imagen, déjalo null.
        /// </summary>
        public Bitmap Image { get; set; }

        /// <summary>
        /// tamaño de la imagen (si la hay).
        /// </summary>
        public int ImageSize { get; set; } = 18;

        /// <summary>
        /// Alineación: "left", "center", o "right"
        /// Afecta tanto al texto como a la imagen (si lo hay).
        /// </summary>
        public string Alignment { get; set; } = "left";

        /// <summary>
        /// Fuente para el texto (solo si 'Text' no es null/vacío).
        /// </summary>
        public string FontFamily { get; set; } = "Consolas";

        /// <summary>
        /// Tamaño de la fuente (solo si 'Text' no es null/vacío).
        /// </summary>
        public float FontSize { get; set; } = 10f;

        /// <summary>
        /// Espacio (en píxeles) que se deja debajo de este elemento 
        /// antes de imprimir el siguiente.
        /// </summary>
        public float SpacingAfter { get; set; } = 10f;
    }
}


