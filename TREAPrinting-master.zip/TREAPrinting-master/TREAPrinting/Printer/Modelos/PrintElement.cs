﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TREAPrinting.Printer.Modelos
{
    namespace TREAPrinting
    {
        public class PrintElement
        {
            /// <summary>
            /// Texto opcional a imprimir.
            /// Si no quieres imprimir texto, déjalo null o vacío.
            /// </summary>
            public string? Text { get; set; }

            /// <summary>
            /// Imagen opcional (logo, QR, etc.)
            /// Si no hay imagen, déjalo null.
            /// </summary>
            public byte[]? ImageData { get; set; }

            /// <summary>
            /// tamaño de la imagen (si la hay).
            /// </summary>
            public int ImageSize { get; set; } = 18;

            /// <summary>
            /// Alineación: "left", "center", o "right"
            /// Afecta tanto al texto como a la imagen (si lo hay).
            /// </summary>
            public string Alignment { get; set; } = "left";

            /// <summary>
            /// Fuente para el texto (solo si 'Text' no es null/vacío).
            /// </summary>
            public string FontFamily { get; set; } = "Consolas";

            /// <summary>
            /// Tamaño de la fuente (solo si 'Text' no es null/vacío).
            /// </summary>
            public float FontSize { get; set; } = 10f;

            /// <summary>
            /// Espacio (en píxeles) que se deja debajo de este elemento
            /// antes de imprimir el siguiente.
            /// </summary>
            public float SpacingAfter { get; set; } = 10f;

            /// <summary>
            /// Si es true, aplica difusión de error (Floyd–Steinberg) al convertir
            /// la imagen a blanco y negro, suavizando degradados y anti-aliasing.
            /// Úsalo para logos/fotos. NO lo actives para códigos QR/barras:
            /// el dithering rompería su legibilidad (usan umbral duro).
            /// Solo afecta a la ruta ESC/POS (Linux).
            /// </summary>
            public bool Dither { get; set; } = false;
        }
    }

}
