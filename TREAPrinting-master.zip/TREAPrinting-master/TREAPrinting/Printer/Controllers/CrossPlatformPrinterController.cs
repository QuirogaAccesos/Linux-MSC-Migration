﻿using QuestPDF.Fluent;
using System.Diagnostics;
using System.Runtime.InteropServices;
using TREAPrinting.Printer.Modelos.TREAPrinting;

namespace TREAPrinting.Printer.Controllers
{
    public class CrossPlatformPrinterController : IPrinterController
    {
        // PrintDynamic es ahora el método principal
        public void PrintDynamic(List<PrintElement> elements, int paperSize, string printerName = "", int marginLeftDots = 0)
        {
            // SI ES LINUX, USA EL MÉTODO NATIVO ESC/POS
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                var escposGenerator = new EscPosGenerator();
                // Usamos el ancho en puntos para 58mm (384) o 80mm (576)
                int printerWidthInDots = (paperSize == 80) ? 576 : 384;
                escposGenerator.Print(elements, printerName, printerWidthInDots, marginLeftDots);
            }
            // PARA CUALQUIER OTRO SO (WINDOWS), USA QUESTPDF
            else
            {
                var document = new Documents(elements, paperSize);
                byte[] pdfBytes = document.GeneratePdf();
                SendToPrinter(pdfBytes, printerName); // Un método renombrado para mayor claridad
            }
        }

        // El método Print original ahora construye la lista de elementos y llama a PrintDynamic
        public void Print(
            string templateAdress, Dictionary<string, string> variableDictionary,
            string TextFont, int TextSize, int PaperSize,
            byte[]? header = null, int HeaderSize = 12, string headerAlignment = "center",
            byte[]? footer = null, int FooterSize = 12, string footerAlignment = "center", string printerName = "")
        {
            // 1. Construir el texto a partir de la plantilla (usando tu lógica existente)
            string replacedText = BuildReplacedText(templateAdress, variableDictionary);

            // 2. Crear la lista de elementos en orden
            var elements = new List<PrintElement>();

            if (header != null)
            {
                elements.Add(new PrintElement { ImageData = header, Alignment = headerAlignment, ImageSize = HeaderSize, SpacingAfter = 10 });
            }

            elements.Add(new PrintElement
            {
                Text = replacedText,
                FontFamily = TextFont,
                FontSize = TextSize,
                Alignment = "left" // O el que prefieras por defecto
            });

            if (footer != null)
            {
                elements.Add(new PrintElement { ImageData = footer, Alignment = footerAlignment, ImageSize = FooterSize, SpacingAfter = 10 });
            }

            // 3. Llamar a PrintDynamic con la lista creada
            PrintDynamic(elements, PaperSize, printerName);
        }

        private void SendToPrinter(byte[] pdfBytes, string printerName = "")
        {
            // Guardar el PDF en un archivo temporal
            string tempPdfFile = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid()}.pdf");
            File.WriteAllBytes(tempPdfFile, pdfBytes);

            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {


                    string sumatraPdfPath = Path.Combine(AppContext.BaseDirectory, "Tools", "SumatraPDF.exe");

                    if (!File.Exists(sumatraPdfPath))
                    {
                        throw new FileNotFoundException("El ejecutable de SumatraPDF no se encuentra en la ruta esperada.", sumatraPdfPath);
                    }

                    // Construir los argumentos para la línea de comandos de SumatraPDF.
                    string arguments;
                    if (string.IsNullOrEmpty(printerName))
                    {
                        arguments = $"-print-to-default -silent -exit-on-print \"{tempPdfFile}\"";
                    }
                    else
                    {
                        arguments = $"-print-to \"{printerName}\" -silent -exit-on-print \"{tempPdfFile}\"";
                    }

                    var startInfo = new ProcessStartInfo
                    {
                        FileName = sumatraPdfPath,
                        Arguments = arguments,
                        CreateNoWindow = true,
                        WindowStyle = ProcessWindowStyle.Hidden,
                        UseShellExecute = false // Llamada directa al .exe
                    };

                    using (var process = Process.Start(startInfo))
                    {
                        process?.WaitForExit(15000); // Timeout de 15 segundos
                    }
                }
                else
                {
                    // Podrías añadir soporte para macOS ('lpr') aquí si lo necesitas
                    throw new PlatformNotSupportedException("Sistema operativo no compatible para impresión directa.");
                }
            }
            finally
            {
                // Limpiar el archivo temporal
                if (File.Exists(tempPdfFile))
                {
                    File.Delete(tempPdfFile);
                }
            }
        }

        // Tu método para construir el texto desde la plantilla
        private string BuildReplacedText(string textFileLocalAddress, Dictionary<string, string> variableDictionary)
        {
            // ... (tu implementación de BuildReplacedText va aquí sin cambios)
            var sb = new System.Text.StringBuilder();
            foreach (var line in File.ReadLines(textFileLocalAddress)) { sb.AppendLine(line); }
            foreach (var kv in variableDictionary) { sb.Replace(kv.Key, kv.Value); }
            return sb.ToString().Replace("@@QR@@", ""); // Quitamos el marcador del QR, ya que se maneja por separado
        }
    }
}
