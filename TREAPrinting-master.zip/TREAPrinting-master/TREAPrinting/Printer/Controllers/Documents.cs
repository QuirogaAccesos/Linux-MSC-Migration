﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using TREAPrinting.Printer.Modelos.TREAPrinting;

namespace TREAPrinting.Printer.Controllers
{
    class Documents : IDocument
    {
        private readonly List<PrintElement> _elements;
        private readonly int _paperWidth;


        public Documents(List<PrintElement> elements, int paperWidth)
        {
            QuestPDF.Settings.License = LicenseType.Community;
            _elements = elements;
            _paperWidth = paperWidth; // Ancho en milímetros (ej: 80mm, 58mm)
        }

        public DocumentMetadata GetMetadata() => DocumentMetadata.Default;

        public void Compose(IDocumentContainer container)
        {
            container.Page(page =>
            {
                // Recibo continuo: ancho fijo (58/80 mm), alto auto
                page.ContinuousSize(_paperWidth, Unit.Millimetre);

                page.Margin(2, Unit.Millimetre);
                page.PageColor(Colors.White);
                page.DefaultTextStyle(s => s.FontFamily("Consolas").FontSize(10));

                page.Content().Column(column =>
                {
                    foreach (var element in _elements)
                    {
                        var item = column.Item();

                        if (element.SpacingAfter > 0)
                            item = item.PaddingBottom(element.SpacingAfter, Unit.Point);

                        // Alineación del CONTENEDOR
                        item = (element.Alignment?.ToLowerInvariant()) switch
                        {
                            "center" => item.AlignCenter(),
                            "right" => item.AlignRight(),
                            _ => item.AlignLeft()
                        };

                        item.Column(inner =>
                        {
                            // IMAGEN: para que se “centre” visualmente, evita ocupar 100% del ancho
                            if (element.ImageData is { Length: > 0 })
                            {
                                inner.Item()
                                     .AlignCenter()
                                     .MaxWidth(_paperWidth * 2.83465f * 0.8f) // límite ~80% (opcional)
                                     .Image(element.ImageData)
                                     .FitWidth(); // ajusta dentro del límite
                            }

                            if (!string.IsNullOrWhiteSpace(element.Text))
                            {
                                inner.Item().Text(t =>
                                {
                                    // Alineación del PÁRRAFO
                                    switch (element.Alignment?.ToLowerInvariant())
                                    {
                                        case "center": t.AlignCenter(); break;
                                        case "right": t.AlignRight(); break;
                                        default: t.AlignLeft(); break;
                                    }

                                    // Estilo en el SPAN (aquí sí vale FontFamily/FontSize)
                                    t.Span(element.Text)
                                     .FontFamily(element.FontFamily ?? "Consolas")
                                     .FontSize(element.FontSize > 0 ? element.FontSize : 10);
                                });
                            }
                        });
                    }
                });
            });
        }
    }
}
