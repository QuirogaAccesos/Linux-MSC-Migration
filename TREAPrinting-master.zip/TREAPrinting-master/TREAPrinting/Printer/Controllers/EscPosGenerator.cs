﻿using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TREAPrinting.Printer.Modelos.TREAPrinting;
using SixLabors.ImageSharp.Processing;

namespace TREAPrinting.Printer.Controllers
{
    internal class EscPosGenerator
    {
        // Método público principal para la clase
        public void Print(List<PrintElement> elements, string printerName, int printerWidthInDots = 384, int marginLeftDots = 0)
        {
            byte[] commands = GenerateCommands(elements, printerWidthInDots, marginLeftDots);
            SendBytesToPrinter(printerName, commands);
        }

        private byte[] GenerateCommands(List<PrintElement> elements, int printerWidthInDots, int marginLeftDots = 0)
        {
            using (var ms = new MemoryStream())
            {
                AddCommand(ms, new byte[] { 0x1B, 0x40 }); // Inicializar impresora

                // Definir el área de impresión = ancho real del papel (con margen
                // izquierdo opcional). Sin esto la impresora no toma el ancho del
                // papel como referencia y el centrado (ESC a 1) queda anclado al
                // borde izquierdo del cabezal.
                if (marginLeftDots < 0) marginLeftDots = 0;
                if (marginLeftDots > printerWidthInDots) marginLeftDots = 0;
                int areaWidth = printerWidthInDots - marginLeftDots;
                // GS L nL nH -> margen izquierdo (en puntos)
                AddCommand(ms, new byte[] { 0x1D, 0x4C, (byte)(marginLeftDots % 256), (byte)(marginLeftDots / 256) });
                // GS W nL nH -> ancho del área de impresión (en puntos)
                AddCommand(ms, new byte[] { 0x1D, 0x57, (byte)(areaWidth % 256), (byte)(areaWidth / 256) });

                foreach (var element in elements)
                {
                    if (element.ImageData != null && element.ImageData.Length > 0)
                    {
                        AppendImage(ms, element.ImageData, areaWidth, element.Alignment, element.Dither);
                    }
                    else if (!string.IsNullOrEmpty(element.Text))
                    {
                        AppendText(ms, element.Text, element.Alignment, areaWidth);
                    }
                }

                AddCommand(ms, new byte[] { 0x0A, 0x0A }); // Espacio antes de cortar
                AddCommand(ms, new byte[] { 0x1D, 0x56, 0x01 }); // Corte parcial

                return ms.ToArray();
            }
        }

        // Ancho aproximado de un carácter de la fuente A ESC/POS a 203 dpi.
        private const int CharWidthDots = 12;

        private void AppendText(MemoryStream ms, string text, string? alignment, int areaWidth)
        {
            // Siempre imprimimos alineado a la izquierda (ESC a 0). El centrado de bloque
            // se logra por geometría (sangría calculada), no por el firmware, que centra
            // cada línea por separado y rompe el aspecto de bloque alineado a la izquierda.
            AddCommand(ms, new byte[] { 0x1B, 0x61, 0x00 });

            bool centerBlock = string.Equals(alignment, "center", StringComparison.OrdinalIgnoreCase);

            // Normalizamos saltos de línea y recortamos espacios finales por línea.
            string[] lines = text.Replace("\r\n", "\n").Replace("\r", "\n").Split('\n');

            int indent = 0;
            if (centerBlock)
            {
                int charsPerLine = areaWidth / CharWidthDots; // 32 para 58mm, 48 para 80mm
                int maxLen = 0;
                foreach (var line in lines)
                {
                    int len = line.TrimEnd().Length;
                    if (len > maxLen) maxLen = len;
                }
                indent = Math.Max(0, (charsPerLine - maxLen) / 2);
            }

            // Codificación UTF-8, fiable para impresoras de recibos modernas.
            Encoding enc = Encoding.UTF8;
            string pad = indent > 0 ? new string(' ', indent) : string.Empty;

            var sb = new StringBuilder();
            foreach (var line in lines)
            {
                string trimmed = line.TrimEnd();
                // Las líneas vacías se imprimen vacías (sin sangría) para no desperdiciar papel.
                sb.Append(trimmed.Length > 0 ? pad + trimmed : string.Empty);
                sb.Append('\n');
            }
            AddCommand(ms, enc.GetBytes(sb.ToString()));
        }

        private void AppendImage(MemoryStream ms, byte[] imageData, int areaWidth, string? alignment, bool dither = false)
        {
            // El centrado NO se delega al firmware (ESC a). La mayoría de impresoras
            // térmicas ignoran ESC a para imágenes raster (GS v 0) y la imagen queda
            // anclada al borde izquierdo. En su lugar, centramos por geometría: el raster
            // se emite con el ancho completo del área de impresión y la imagen se desplaza
            // dentro de él con relleno blanco. Así el centrado depende del ancho del papel.
            AddCommand(ms, new byte[] { 0x1B, 0x61, 0x00 });

            using (Image<Rgba32> image = Image.Load<Rgba32>(imageData))
            {
                // Paridad con la ruta de Windows (QuestPDF usa ~80% del ancho del papel).
                int maxWidth = (int)(areaWidth * 0.8);

                // Solo reducir si la imagen es más ancha que el tope; nunca ampliar.
                // El overload Resize(width, 0) calcula el alto proporcional automáticamente.
                if (image.Width > maxWidth)
                    image.Mutate(x => x.Resize(maxWidth, 0));

                // Aplanar la transparencia sobre fondo blanco: los logos son PNG RGBA
                // y, sin esto, los píxeles transparentes (R=0) se imprimen como bloques negros.
                image.Mutate(x => x.BackgroundColor(Color.White));
                image.Mutate(x => x.Grayscale());

                // Difusión de error (Floyd–Steinberg) para suavizar degradados/anti-aliasing
                // al pasar a B/N. Solo para logos/fotos; el QR conserva su umbral duro.
                if (dither)
                    image.Mutate(x => x.BinaryDither(KnownDitherings.FloydSteinberg));

                // Desplazamiento horizontal (en dots) para colocar la imagen dentro del
                // ancho completo del papel según la alineación pedida.
                int offsetX;
                switch (alignment?.ToLower())
                {
                    case "right": offsetX = areaWidth - image.Width; break;
                    case "left": offsetX = 0; break;
                    default: offsetX = (areaWidth - image.Width) / 2; break; // center
                }
                if (offsetX < 0) offsetX = 0;

                // El raster abarca el ancho completo del área de impresión.
                int widthInBytes = (areaWidth + 7) / 8;
                int heightInDots = image.Height;

                byte[] cmdHeader = { 0x1D, 0x76, 0x30, 0x00, (byte)(widthInBytes % 256), (byte)(widthInBytes / 256), (byte)(heightInDots % 256), (byte)(heightInDots / 256) };
                AddCommand(ms, cmdHeader);

                for (int y = 0; y < image.Height; y++)
                {
                    for (int xByte = 0; xByte < widthInBytes; xByte++)
                    {
                        byte slice = 0;
                        for (int bit = 0; bit < 8; bit++)
                        {
                            // x absoluto dentro del papel; el píxel de la imagen es x - offsetX.
                            int x = xByte * 8 + bit;
                            int srcX = x - offsetX;
                            if (srcX >= 0 && srcX < image.Width && image[srcX, y].R < 128)
                            {
                                slice |= (byte)(1 << (7 - bit));
                            }
                        }
                        ms.WriteByte(slice);
                    }
                }
            }
            AddCommand(ms, new byte[] { 0x0A }); // Salto de línea después de la imagen
            AddCommand(ms, new byte[] { 0x1B, 0x61, 0x00 }); // Restaurar alineación a la izquierda
        }

        private void AddCommand(MemoryStream ms, byte[] command) => ms.Write(command, 0, command.Length);

        private void SendBytesToPrinter(string printerName, byte[] data)
        {
            var tempFilePath = Path.GetTempFileName();
            File.WriteAllBytes(tempFilePath, data);

            try
            {
                string lp_args;
                // Si no se provee nombre de impresora, no se usa el argumento -d para que CUPS use la default.
                if (string.IsNullOrEmpty(printerName))
                {
                    lp_args = $"-o raw \"{tempFilePath}\"";
                }
                else
                {
                    lp_args = $"-d \"{printerName}\" -o raw \"{tempFilePath}\"";
                }

                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "lp",
                        Arguments = lp_args,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };
                process.Start();
                process.WaitForExit(10000);
            }
            finally
            {
                File.Delete(tempFilePath);
            }
        }
    }
}
