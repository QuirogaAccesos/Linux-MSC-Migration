﻿using System.Drawing;
using TREAPrinting.Printer.Modelos.TREAPrinting;

namespace TREAPrinting
{
    public interface IPrinterController
    {
        /// <summary>
        /// Replaces the template string with the variable values, set the text font and size for the printed output
        /// </summary>
        /// <param name="templateAdress"></param>
        /// <param name="variableDictionary"></param>
        /// <param name="TextFont"></param>
        /// <param name="TextSize"></param>
        /// <param name="header"></param>
        /// <param name="footer"></param>
        void Print(string templateAdress, Dictionary<string, string> variableDictionary, string TextFont, int TextSize, int PaperSize,
            byte[]? header = null, int HeaderSize = 12, string headerAlignment = "center",
            byte[]? footer = null, int FooterSize = 12, string footerAlignment = "center", string printerName = "");


        void PrintDynamic(
           List<PrintElement> elements,
           int paperSize, string printerName = "", int marginLeftDots = 0
       );
    }
}
